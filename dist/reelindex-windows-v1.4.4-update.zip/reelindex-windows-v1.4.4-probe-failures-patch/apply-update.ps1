$ErrorActionPreference = 'Stop'
$InstallDir = Join-Path $env:LOCALAPPDATA 'Programs\ReelIndex'
$DataDir = Join-Path $env:LOCALAPPDATA 'ReelIndex'
$PidFile = Join-Path $DataDir 'server.pid'

if (-not (Test-Path (Join-Path $InstallDir 'ReelIndex.exe'))) {
    throw "ReelIndex is not installed at $InstallDir"
}

if (Test-Path $PidFile) {
    $pidText = (Get-Content $PidFile -Raw).Trim()
    if ($pidText -match '^\d+$') {
        & taskkill.exe /PID $pidText /T /F 2>$null | Out-Null
        Start-Sleep -Seconds 1
    }
}

$copies = @(
    @('app\app\api\movies.py', 'app\app\api\movies.py'),
    @('app\app\api\probes.py', 'app\app\api\probes.py'),
    @('app\app\api\system.py', 'app\app\api\system.py'),
    @('app\app\schemas\api.py', 'app\app\schemas\api.py'),
    @('app\app\services\probe_failures.py', 'app\app\services\probe_failures.py'),
    @('app\app\services\scanner.py', 'app\app\services\scanner.py'),
    @('app\app\main.py', 'app\app\main.py'),
    @('app\web\app.js', 'app\web\app.js'),
    @('app\web\styles.css', 'app\web\styles.css'),
    @('app\web\index.html', 'app\web\index.html')
)
foreach ($pair in $copies) {
    $destination = Join-Path $InstallDir $pair[1]
    New-Item -ItemType Directory -Path (Split-Path $destination) -Force | Out-Null
    Copy-Item (Join-Path $PSScriptRoot $pair[0]) $destination -Force
}

Get-ChildItem (Join-Path $InstallDir 'app') -Directory -Recurse -Filter '__pycache__' -ErrorAction SilentlyContinue |
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue

$uninstallKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\ReelIndex'
if (Test-Path $uninstallKey) {
    Set-ItemProperty $uninstallKey DisplayVersion '1.4.4'
}

Start-Process (Join-Path $InstallDir 'ReelIndex.exe')
Write-Host 'ReelIndex v1.4.4 applied. Existing data, posters, sources, credentials, scan history, and deep queues were preserved.'
