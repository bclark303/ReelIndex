ReelIndex Windows v1.4.4

1. Extract this ZIP.
2. Open PowerShell in the extracted folder.
3. Run:

   powershell -ExecutionPolicy Bypass -File .\apply-update.ps1

After ReelIndex opens, confirm the footer says 1.4.4.

New in this release:
- A dedicated Probe failures page listing every current analyzer failure.
- Cause classification, full errors, paths, attempt counts, and remediation guidance.
- Filters by source, cause, and container.
- One-file native, extended, and ffprobe compatibility retries.
- The same retry and diagnosis controls in movie details.
- Bounded failure history retained across subsequent attempts.
