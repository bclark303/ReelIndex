$ErrorActionPreference = 'Stop'
$InstallDir = Join-Path $env:LOCALAPPDATA 'Programs\ReelIndex'
$DataDir = Join-Path $env:LOCALAPPDATA 'ReelIndex'
$PidFile = Join-Path $DataDir 'server.pid'

if (-not (Test-Path (Join-Path $InstallDir 'ReelIndex.exe'))) {
    throw "ReelIndex is not installed at $InstallDir"
}

if (Test-Path $PidFile) {
    $pidText = (Get-Content $PidFile -Raw).Trim()
    if ($pidText -match '^\d+$') {
        & taskkill.exe /PID $pidText /T /F 2>$null | Out-Null
        Start-Sleep -Seconds 1
    }
}

$sourceApp = Join-Path $PSScriptRoot 'app'
$destinationApp = Join-Path $InstallDir 'app'
New-Item -ItemType Directory -Path $destinationApp -Force | Out-Null
Copy-Item (Join-Path $sourceApp '*') $destinationApp -Recurse -Force

Get-ChildItem $destinationApp -Directory -Recurse -Filter '__pycache__' -ErrorAction SilentlyContinue |
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue

$uninstallKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\ReelIndex'
if (Test-Path $uninstallKey) {
    Set-ItemProperty $uninstallKey DisplayVersion '1.4.5'
}

Start-Process (Join-Path $InstallDir 'ReelIndex.exe')
Write-Host 'ReelIndex 1.4.5 was installed. Application data was preserved.'
