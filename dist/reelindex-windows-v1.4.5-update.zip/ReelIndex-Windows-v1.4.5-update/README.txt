ReelIndex Windows v1.4.5 in-place update

1. Extract this ZIP.
2. Open PowerShell in the extracted folder.
3. Run:

   powershell -ExecutionPolicy Bypass -File .\apply-update.ps1

The updater replaces only program code under
%LOCALAPPDATA%\Programs\ReelIndex\app.

It preserves the database, source connections, encrypted credentials, posters,
scan history, scan logs, and resumable Deep Scan queues under
%LOCALAPPDATA%\ReelIndex.

v1.4.5 synchronizes the Windows and Docker/Unraid editions on the same backend
and browser UI. The visible Windows feature set is otherwise unchanged from
v1.4.4.
